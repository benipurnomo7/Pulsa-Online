<?php


$MySQL = array(
    'host' => 'localhost', // MySQL Host
    'user' => 'root', // MySQL User
    'pass' => '', // MySQL Password
    'name' => 'pulsa_online', // MySQL Database Name
    );

